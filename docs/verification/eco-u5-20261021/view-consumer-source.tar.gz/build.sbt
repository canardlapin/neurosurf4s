import org.scalajs.linker.interface.ModuleKind
import sbtcrossproject.CrossPlugin.autoImport.*
import sbtcrossproject.CrossType
import scalajscrossproject.ScalaJSCrossPlugin.autoImport.*
ThisBuild / scalaVersion := "3.7.4"
lazy val provider = uri("file:///var/folders/9h/nkjq6vss7mqdl4ck7q1hd8ph0000gp/T/neurosurf4s-view-provider-hsouufwo")
lazy val consumer = crossProject(JSPlatform, JVMPlatform).crossType(CrossType.Full).in(file("consumer"))
  .settings(scalacOptions ++= Seq("-deprecation", "-feature", "-unchecked", "-Werror"), Test / fork := false,
    libraryDependencies += "org.scalameta" %%% "munit" % "1.2.1" % Test)
  .jvmConfigure(_.dependsOn(ProjectRef(provider, "viewRasterJVM")))
  .jsConfigure(_.dependsOn(ProjectRef(provider, "viewRasterJS")))
  .jsSettings(scalaJSLinkerConfig ~= (_.withModuleKind(ModuleKind.CommonJSModule)))
lazy val root = project.in(file(".")).aggregate(consumer.jvm, consumer.js)
