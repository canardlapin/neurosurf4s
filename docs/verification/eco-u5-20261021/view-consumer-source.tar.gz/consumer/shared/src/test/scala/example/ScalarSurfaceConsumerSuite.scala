package example

import intaglio.*
import neurosurf4s.surface.*
import neurosurf4s.surface.view.*
import neurosurf4s.surface.view.raster.*

class ScalarSurfaceConsumerSuite extends munit.FunSuite:
  test("a scalar surface compiles and renders independent pixel, pick and readout witnesses"):
    val geometry = SurfaceGeometry(TriangleMesh.fromRows(
      Vector(Vector(-1.0, -1.0, 0.0), Vector(1.0, -1.0, 0.0), Vector(-0.6, 0.8, 0.0)),
      Vector((0, 1, 2))), Hemisphere.Left, SurfaceKind.Pial)
    val surface = SurfaceId.unsafe("external-scalar")
    val layer = SurfaceLayer.scalar(SurfaceLayerId.unsafe("signal"), surface, geometry,
      Array(0.5, 0.5, 0.5), ScalarColorizer(DisplayWindow.unsafe(0.0, 1.0))).toOption.get
    val model = SurfaceViewerModel.make(Vector(SurfaceAsset.make(surface, geometry).toOption.get), Vector(layer)).toOption.get
    val state = Vector(
      SurfaceViewerAction.SetViewpoint(SurfaceViewpoint.Dorsal),
      SurfaceViewerAction.SetLighting(SurfaceLighting.Unlit),
      SurfaceViewerAction.SetProjection(CameraProjection.Orthographic(OrthographicScale.unsafe(1.25))),
      SurfaceViewerAction.Select(surface, VertexId(0))
    ).foldLeft(SurfaceViewerState.initial(model))((s, action) => SurfaceViewer.reduce(model, s, action).toOption.get)
    val plan = SurfaceCompiler.compile(model, state).toOption.get
    val observed = SurfaceRasterizer.renderObserved(plan, RasterDimensions.unsafe(64, 64), path = SurfaceAdmissionPath.Snapshot).toOption.get
    val image = observed.result
    // Independent half-plane enumeration for this orthographic triangle covers1175 pixel centers.
    assertEquals(image.receipt.shadedPixels, 1175)
    assertEquals(image.image.pixelUnsafe(30, 40).toPackedInt, Rgba32.unsafe(128, 128, 128).toPackedInt)
    val hit = image.pick(9, 54).toOption.flatten.get
    assertEquals(hit.surface, surface)
    assertEquals(hit.vertex, 0)
    assertEquals(hit.face, 0)
    assertEqualsDouble(hit.barycentricA + hit.barycentricB + hit.barycentricC, 1.0, 1e-5)
    assertEquals(plan.readouts.head.vertex, 0)
    assertEqualsDouble(plan.readouts.head.layerValues.head._2.toDouble, 0.5, 0.0)
    assertEquals(SurfaceBackendAdmission.validate(observed.observation), Vector.empty)
