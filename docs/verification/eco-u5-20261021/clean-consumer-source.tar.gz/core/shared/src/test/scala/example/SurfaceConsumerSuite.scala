package example

import neurosurf4s.surface.*
import neuroim4s.spaces.*
import locus4s.{DomainId, Region}
import spatial4s.Xyz
import scala.concurrent.ExecutionContext.Implicits.global

class SurfaceConsumerSuite extends munit.FunSuite:
  private val vertices = Vector(Vector(0.0, 0.0, 0.0), Vector(1.0, 0.0, 0.0), Vector(1.0, 1.0, 0.0), Vector(0.0, 1.0, 0.0))
  private val geometry = SurfaceGeometry(TriangleMesh.fromRows(vertices, Vector((0, 1, 2), (0, 2, 3))), Hemisphere.Left, SurfaceKind.Pial)
  private val xml = """<GIFTI Version="1.0" NumberOfDataArrays="2">
    <DataArray Intent="NIFTI_INTENT_POINTSET" DataType="NIFTI_TYPE_FLOAT64" ArrayIndexingOrder="RowMajorOrder" Dimensionality="2" Dim0="4" Dim1="3" Encoding="ASCII" Endian="LittleEndian"><Data>0 0 0 1 0 0 1 1 0 0 1 0</Data></DataArray>
    <DataArray Intent="NIFTI_INTENT_TRIANGLE" DataType="NIFTI_TYPE_INT32" ArrayIndexingOrder="RowMajorOrder" Dimensionality="2" Dim0="2" Dim1="3" Encoding="ASCII" Endian="LittleEndian"><Data>0 1 2 0 2 3</Data></DataArray></GIFTI>"""

  test("public GIFTI ingestion retains ordered topology and compact center embedding"):
    PlatformReader.read(xml).map: result =>
      val decoded = result.fold(fail(_), identity)
      assertEquals(decoded.mesh.topologyIdentity.stableKey, "fcf7e2e81f78e46f")
      assertEquals(decoded.mesh.coordinates.toVector, vertices.flatten)
      val domain = SurfaceLocusDomain.semantic(DomainId.parse("external:left").toOption.get, decoded).toOption.get.value
      val centers = Region.fromOrdinals(domain.finiteSpace, Vector(1, 3)).toOption.get
      val neighborhoods = SurfaceSearchlight.metricBalls(domain, MeshTopology.from(decoded), 1.0, centers).toOption.get.value
      assertEquals(neighborhoods.centerEmbedding.toTotalMap.targetOrdinals.toVector, Vector(1, 3))
      assertEquals(neighborhoods.membership.ordinalRows.map(_.toVector).toVector, Vector(Vector(0, 1, 2), Vector(0, 2, 3)))
      assert(neighborhoods.ambient.sameRuntimeOwnerAs(domain.topology.vertices))

  test("semantic restore preserves persistent identity and never invents a shared live owner"):
    val key = DomainId.parse("external:left").toOption.get
    val first = SurfaceLocusDomain.semantic(key, geometry).toOption.get.value
    val second = SurfaceLocusDomain.semantic(key, geometry).toOption.get.value
    assertEquals(first.finiteSpace.id.value, "external:left:surface:lh:4:2:fcf7e2e81f78e46f")
    assert(!first.finiteSpace.sameRuntimeOwnerAs(second.finiteSpace))
    assert(first.finiteSpace.align(second.finiteSpace).isRight)
    val labels = LabeledSurface.fromIndexed(geometry, Vector(VertexId(0), VertexId(1), VertexId(2), VertexId(3)), Vector(7, 9, 7, 99), Vector(LabelInfo(7, "first"), LabelInfo(9, "second"), LabelInfo(99, "ignored")))
    val parcels = first.parcellation(labels, Set(99)).toOption.get
    assertEquals(parcels.assignment.optionalTargetOrdinals, Vector(Some(0), Some(1), Some(0), None))
    assertEquals(parcels.fibers.ordinalRows.map(_.toVector).toVector, Vector(Vector(0, 2), Vector(1)))

  test("raw XYZ does not infer a world and dependent placement binds only to the declared template"):
    val raw: Xyz = geometry.mesh.vertex(VertexId(1))
    assertEquals(raw, Xyz(1.0, 0.0, 0.0))
    val placed = FramedSurface.inWorld(WorldSpace.template("fsaverage").toOption.get)(geometry, SurfacePlacement.StoredCoordinates).toOption.get
    val bound: FramedSurface[Spaces.FsAverage] = placed.bindTo(Spaces.fsaverage).toOption.get
    assert(bound.frame.sameRuntimeOwnerAs(Spaces.fsaverage))
    assertEquals(bound.vertex(VertexId(1)).toOption.get.coordinates, raw.toVector)
    assert(placed.bindTo(Spaces.MNI152NLin2009cAsym).isLeft)
