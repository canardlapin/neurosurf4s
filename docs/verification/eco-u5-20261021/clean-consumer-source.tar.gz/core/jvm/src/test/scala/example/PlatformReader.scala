package example

import java.nio.file.Files
import neurosurf4s.surface.{Hemisphere, SurfaceGeometry, SurfaceKind}
import neurosurf4s.surface.io.GiftiSurfaceReader
import scala.concurrent.Future

object PlatformReader:
  def read(xml: String): Future[Either[String, SurfaceGeometry]] =
    val path = Files.createTempFile("neurosurf-consumer-", ".surf.gii")
    try
      Files.writeString(path, xml)
      Future.successful(GiftiSurfaceReader.readEither(path, Hemisphere.Left, SurfaceKind.Pial).left.map(_.message))
    finally Files.deleteIfExists(path)
