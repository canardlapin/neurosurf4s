import org.scalajs.linker.interface.ModuleKind
import org.scalajs.sbtplugin.ScalaJSPlugin.autoImport.*
import sbtcrossproject.CrossPlugin.autoImport.*
import sbtcrossproject.CrossType
import scalajscrossproject.ScalaJSCrossPlugin.autoImport.*
ThisBuild / scalaVersion := "3.7.4"
lazy val provider = uri("file:///var/folders/9h/nkjq6vss7mqdl4ck7q1hd8ph0000gp/T/neurosurf4s-eco-u5-provider-1lsr8cmf")
lazy val settings = Seq(
  scalacOptions ++= Seq("-deprecation", "-feature", "-unchecked", "-Werror"),
  Test / fork := false,
  libraryDependencies += "org.scalameta" %%% "munit" % "1.2.1" % Test
)
lazy val jsSettings = Seq(scalaJSLinkerConfig ~= (_.withModuleKind(ModuleKind.CommonJSModule)))
lazy val coreConsumer = crossProject(JSPlatform, JVMPlatform).crossType(CrossType.Full).in(file("core"))
  .settings(settings).jsSettings(jsSettings)
  .jvmConfigure(_.dependsOn(ProjectRef(provider, "coreJVM"), ProjectRef(provider, "ioJVM")))
  .jsConfigure(_.dependsOn(ProjectRef(provider, "coreJS"), ProjectRef(provider, "ioJS")))
lazy val volumeConsumer = crossProject(JSPlatform, JVMPlatform).crossType(CrossType.Full).in(file("volume"))
  .settings(settings).jsSettings(jsSettings)
  .jvmConfigure(_.dependsOn(ProjectRef(provider, "volumeJVM")))
  .jsConfigure(_.dependsOn(ProjectRef(provider, "volumeJS")))
lazy val root = project.in(file(".")).aggregate(coreConsumer.jvm, coreConsumer.js, volumeConsumer.jvm, volumeConsumer.js)
